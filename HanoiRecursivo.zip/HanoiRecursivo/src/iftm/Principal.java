package iftm;

import java.util.Scanner;
import java.util.Stack;

public class Principal {
	
	static int resultado = 0, nArgolas = 0;
	static Stack torre1 = new Stack();

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Informe a quantidade de argolas: ");
		nArgolas = sc.nextInt();
		
		/*for (int i = nArgolas; i > 0; i--) {
			torre1.push(i);
		}
		
		for (int i = 0; i < nArgolas;i++) {
			System.out.println(torre1.peek());
			torre1.pop();
		}*/
		
		//multiplicacao(4,5);
		resolverHanoi(nArgolas,1,3,2);

	}
	
	static int passo = 1;
	
	public static int multiplicacao(int num1, int num2) {
		
		resultado = resultado + num1;
		num2--;
		if(num2 == 0) {
			
			System.out.println(resultado);
			
			return resultado;
		}else {
			return multiplicacao(num1, num2);
		}
		
	}
	
	private static void movimento(int origem, int destino) {
		System.out.print("Passo: "+passo + " |\t");
		System.out.println(origem + " -> " + destino);
		passo++;
	}

	static void resolverHanoi(int n, int origem, int destino, int trabalho) {

		if (n > 0) {
			resolverHanoi(n - 1, origem, trabalho, destino);
			movimento(origem, destino);
			resolverHanoi(n - 1, trabalho, destino, origem);
		}

	}
	

}
